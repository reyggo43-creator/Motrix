package com.motrix.model

import kotlin.math.min

data class FitRect(val left: Float, val top: Float, val width: Float, val height: Float)

/**
 * Letterbox composition (compW x compH) ke dalam wadah, di tengah, rasio terjaga.
 * Dipakai bersama oleh renderer GL dan overlay Compose agar keduanya selalu sejajar.
 */
fun fitRect(containerW: Float, containerH: Float, compW: Int, compH: Int): FitRect {
    val scale = min(containerW / compW, containerH / compH)
    val w = compW * scale
    val h = compH * scale
    return FitRect((containerW - w) / 2f, (containerH - h) / 2f, w, h)
}
