package com.motrix.model

import java.util.Locale

/** "mm:ss:ff" */
fun formatTimecode(frame: Int, fps: Int): String {
    val totalSeconds = frame / fps
    return String.format(Locale.ROOT, "%02d:%02d:%02d", totalSeconds / 60, totalSeconds % 60, frame % fps)
}
