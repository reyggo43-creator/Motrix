package com.motrix.model

/** Posisi pemutaran dalam satuan frame (pecahan) dan status play. */
data class Playhead(val position: Double = 0.0, val playing: Boolean = false) {

    fun frame(durationFrames: Int): Int = position.toInt().coerceIn(0, durationFrames - 1)

    /** Maju sebesar [dtSeconds]; loop ke awal saat melewati akhir. Diam jika jeda. */
    fun advance(dtSeconds: Double, fps: Int, durationFrames: Int): Playhead {
        if (!playing || dtSeconds <= 0.0) return this
        var p = position + dtSeconds * fps
        if (p >= durationFrames) p %= durationFrames
        return copy(position = p)
    }

    fun seek(frame: Double, durationFrames: Int): Playhead =
        copy(position = frame.coerceIn(0.0, (durationFrames - 1).toDouble()))
}
