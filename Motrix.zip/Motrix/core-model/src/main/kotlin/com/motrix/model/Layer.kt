package com.motrix.model

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** [code] harus sama dengan nilai uShape di shader native. */
enum class ShapeType(val code: Float) { RECTANGLE(0f), ELLIPSE(1f) }

/**
 * Satu layer. Koordinat dalam piksel composition, origin kiri-atas, sumbu y ke bawah;
 * (x, y) adalah titik tengah. Rentang waktu [inFrame, outFrame) — outFrame eksklusif.
 */
data class Layer(
    val id: Long,
    val name: String,
    val shape: ShapeType,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val rotationDeg: Float = 0f,
    val opacity: Float = 1f,
    /** RGB 0xRRGGBB. */
    val color: Int,
    val inFrame: Int,
    val outFrame: Int,
    val visible: Boolean = true,
) {
    val length: Int get() = outFrame - inFrame

    fun isActiveAt(frame: Int): Boolean = visible && frame >= inFrame && frame < outFrame

    /** Hit-test pada titik (px, py) dalam koordinat composition. */
    fun contains(px: Float, py: Float): Boolean {
        val rad = Math.toRadians(rotationDeg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val dx = px - x
        val dy = py - y
        val lx = (c * dx + s * dy) / width
        val ly = (-s * dx + c * dy) / height
        return when (shape) {
            ShapeType.RECTANGLE -> abs(lx) <= 0.5f && abs(ly) <= 0.5f
            ShapeType.ELLIPSE -> lx * lx + ly * ly <= 0.25f
        }
    }

    /** Empat sudut kotak pembatas setelah rotasi: [x0,y0, x1,y1, x2,y2, x3,y3] searah jarum jam. */
    fun corners(): FloatArray {
        val rad = Math.toRadians(rotationDeg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val hw = width / 2f
        val hh = height / 2f
        val local = floatArrayOf(-hw, -hh, hw, -hh, hw, hh, -hw, hh)
        val out = FloatArray(8)
        for (i in 0 until 4) {
            val lx = local[i * 2]
            val ly = local[i * 2 + 1]
            out[i * 2] = x + c * lx - s * ly
            out[i * 2 + 1] = y + s * lx + c * ly
        }
        return out
    }
}
