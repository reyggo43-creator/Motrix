package com.motrix.model

/**
 * Format larik float yang dikirim ke engine native (harus sama dengan konstanta di renderer.cpp):
 *   header  : [compW, compH, bgR, bgG, bgB, layerCount]
 *   per layer: [shape, cx, cy, w, h, rotasiRad, r, g, b, opacity]
 */
object SceneFormat {
    const val HEADER = 6
    const val LAYER_STRIDE = 10
}

/** Susun scene untuk [frame]: hanya layer aktif, urutan gambar dari paling bawah ke atas. */
fun Composition.buildScene(frame: Int): FloatArray {
    val active = layers.asReversed().filter { it.isActiveAt(frame) }
    val out = FloatArray(SceneFormat.HEADER + active.size * SceneFormat.LAYER_STRIDE)
    out[0] = width.toFloat()
    out[1] = height.toFloat()
    out[2] = red(background)
    out[3] = green(background)
    out[4] = blue(background)
    out[5] = active.size.toFloat()
    active.forEachIndexed { i, l ->
        val o = SceneFormat.HEADER + i * SceneFormat.LAYER_STRIDE
        out[o] = l.shape.code
        out[o + 1] = l.x
        out[o + 2] = l.y
        out[o + 3] = l.width
        out[o + 4] = l.height
        out[o + 5] = Math.toRadians(l.rotationDeg.toDouble()).toFloat()
        out[o + 6] = red(l.color)
        out[o + 7] = green(l.color)
        out[o + 8] = blue(l.color)
        out[o + 9] = l.opacity
    }
    return out
}

private fun red(rgb: Int) = ((rgb shr 16) and 0xFF) / 255f
private fun green(rgb: Int) = ((rgb shr 8) and 0xFF) / 255f
private fun blue(rgb: Int) = (rgb and 0xFF) / 255f
