package com.motrix.model

import kotlin.math.max

/**
 * Composition immutable: setiap operasi mengembalikan instance baru, sehingga undo/redo
 * cukup menyimpan salinan. layers[0] = layer paling atas (urutan seperti panel layer).
 */
data class Composition(
    val width: Int = 1920,
    val height: Int = 1080,
    val fps: Int = 30,
    val durationFrames: Int = 150,
    /** RGB 0xRRGGBB. */
    val background: Int = 0x1A1D26,
    val layers: List<Layer> = emptyList(),
    val nextId: Long = 1L,
) {
    fun layer(id: Long): Layer? = layers.firstOrNull { it.id == id }

    fun addLayer(shape: ShapeType, color: Int): Composition {
        val base = if (shape == ShapeType.RECTANGLE) "Persegi" else "Elips"
        val layer = Layer(
            id = nextId,
            name = "$base $nextId",
            shape = shape,
            x = width / 2f,
            y = height / 2f,
            width = 400f,
            height = 400f,
            color = color,
            inFrame = 0,
            outFrame = durationFrames,
        )
        return copy(layers = listOf(layer) + layers, nextId = nextId + 1)
    }

    fun removeLayer(id: Long): Composition = copy(layers = layers.filterNot { it.id == id })

    fun moveLayerOrder(id: Long, delta: Int): Composition {
        val from = layers.indexOfFirst { it.id == id }
        if (from < 0) return this
        val to = (from + delta).coerceIn(0, layers.lastIndex)
        if (to == from) return this
        val m = layers.toMutableList()
        m.add(to, m.removeAt(from))
        return copy(layers = m)
    }

    fun toggleVisible(id: Long): Composition = update(id) { it.copy(visible = !it.visible) }

    /** Geser seluruh bar layer di timeline; panjang tetap, tidak keluar dari [0, durationFrames]. */
    fun shiftTime(id: Long, deltaFrames: Int): Composition = update(id) { l ->
        val len = l.length
        val newIn = (l.inFrame + deltaFrames).coerceIn(0, max(0, durationFrames - len))
        l.copy(inFrame = newIn, outFrame = newIn + len)
    }

    fun translate(id: Long, dx: Float, dy: Float): Composition =
        update(id) { it.copy(x = it.x + dx, y = it.y + dy) }

    private inline fun update(id: Long, f: (Layer) -> Layer): Composition =
        copy(layers = layers.map { if (it.id == id) f(it) else it })

    companion object {
        /** Proyek awal berisi layer sungguhan yang bisa diedit dan dihapus. */
        fun starter(): Composition {
            val c = Composition()
            return c.addLayer(ShapeType.RECTANGLE, 0x4F8CFF)
                .addLayer(ShapeType.ELLIPSE, 0xFF4D6A)
                .let { it.translate(1L, -260f, 60f).translate(2L, 220f, -40f) }
                .let { it.copy(layers = it.layers.map { l -> if (l.id == 2L) l.copy(width = 360f, height = 360f) else l }) }
        }
    }
}
