package com.motrix.model

import org.junit.Assert.assertEquals
import org.junit.Test

class PlayheadTest {
    @Test
    fun advanceDoesNothingWhilePaused() {
        val p = Playhead(position = 10.0, playing = false)
        assertEquals(p, p.advance(1.0, fps = 30, durationFrames = 150))
    }

    @Test
    fun advanceMovesByElapsedSecondsTimesFps() {
        val p = Playhead(position = 0.0, playing = true).advance(0.5, fps = 30, durationFrames = 150)
        assertEquals(15.0, p.position, 1e-9)
    }

    @Test
    fun advanceLoopsBackToStartAtEnd() {
        val p = Playhead(position = 148.0, playing = true).advance(0.2, fps = 30, durationFrames = 150) // +6 => 154
        assertEquals(4.0, p.position, 1e-9)
    }

    @Test
    fun negativeElapsedTimeIsIgnored() {
        val p = Playhead(position = 20.0, playing = true).advance(-1.0, fps = 30, durationFrames = 150)
        assertEquals(20.0, p.position, 1e-9)
    }

    @Test
    fun seekClampsToLastFrame() {
        assertEquals(0.0, Playhead().seek(-5.0, 150).position, 0.0)
        assertEquals(149.0, Playhead().seek(999.0, 150).position, 0.0)
    }

    @Test
    fun frameIsFlooredAndNeverBeyondLastFrame() {
        assertEquals(12, Playhead(position = 12.9).frame(150))
        assertEquals(149, Playhead(position = 150.0).frame(150))
    }
}
