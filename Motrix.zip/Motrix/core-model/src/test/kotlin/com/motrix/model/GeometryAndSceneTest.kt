package com.motrix.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GeometryAndSceneTest {
    private fun layer(shape: ShapeType = ShapeType.RECTANGLE, rot: Float = 0f) = Layer(
        id = 1, name = "L", shape = shape, x = 100f, y = 100f, width = 40f, height = 20f,
        rotationDeg = rot, opacity = 0.5f, color = 0x336699, inFrame = 0, outFrame = 10,
    )

    @Test
    fun fitRectLetterboxesWideCompositionInTallContainer() {
        val r = fitRect(containerW = 400f, containerH = 1000f, compW = 1920, compH = 1080)
        assertEquals(0f, r.left, 1e-3f)
        assertEquals(400f, r.width, 1e-3f)
        assertEquals(225f, r.height, 1e-3f)
        assertEquals((1000f - 225f) / 2f, r.top, 1e-3f)
    }

    @Test
    fun fitRectPillarboxesTallCompositionInWideContainer() {
        val r = fitRect(containerW = 1000f, containerH = 400f, compW = 1080, compH = 1920)
        assertEquals(225f, r.width, 1e-3f)
        assertEquals(400f, r.height, 1e-3f)
        assertEquals((1000f - 225f) / 2f, r.left, 1e-3f)
        assertEquals(0f, r.top, 1e-3f)
    }

    @Test
    fun containsRectangleUnrotated() {
        val l = layer()
        assertTrue(l.contains(119f, 109f))
        assertFalse(l.contains(121f, 100f))
        assertFalse(l.contains(100f, 111f))
    }

    @Test
    fun containsRectangleRotated90SwapsExtents() {
        val l = layer(rot = 90f)
        assertTrue(l.contains(100f, 119f))   // sekarang memanjang vertikal
        assertFalse(l.contains(119f, 100f))
    }

    @Test
    fun containsEllipseRejectsBoundingBoxCorner() {
        val l = layer(ShapeType.ELLIPSE)
        assertTrue(l.contains(100f, 100f))
        assertTrue(l.contains(118f, 100f))
        assertFalse(l.contains(119f, 109f)) // sudut kotak, di luar elips
    }

    @Test
    fun cornersAreRotatedAroundCenter() {
        val c = layer(rot = 90f).corners()
        // sudut (-20,-10) berputar 90° searah jarum jam (y ke bawah) => (10,-20)
        assertEquals(110f, c[0], 1e-3f)
        assertEquals(80f, c[1], 1e-3f)
    }

    @Test
    fun sceneHeaderAndLayerLayoutMatchNativeFormat() {
        val comp = Composition(width = 800, height = 600, background = 0xFF8000, layers = listOf(layer()))
        val s = comp.buildScene(frame = 5)
        assertEquals(SceneFormat.HEADER + SceneFormat.LAYER_STRIDE, s.size)
        assertEquals(800f, s[0], 0f)
        assertEquals(600f, s[1], 0f)
        assertEquals(1f, s[2], 1e-6f)
        assertEquals(128f / 255f, s[3], 1e-6f)
        assertEquals(0f, s[4], 1e-6f)
        assertEquals(1f, s[5], 0f) // jumlah layer
        val o = SceneFormat.HEADER
        assertEquals(0f, s[o], 0f)          // bentuk
        assertEquals(100f, s[o + 1], 0f)    // x
        assertEquals(100f, s[o + 2], 0f)    // y
        assertEquals(40f, s[o + 3], 0f)     // lebar
        assertEquals(20f, s[o + 4], 0f)     // tinggi
        assertEquals(0x33 / 255f, s[o + 6], 1e-6f)
        assertEquals(0.5f, s[o + 9], 0f)    // opacity
    }

    @Test
    fun sceneSkipsInactiveLayersAndDrawsBottomLayerFirst() {
        val top = layer().copy(id = 2, x = 1f)
        val bottom = layer().copy(id = 1, x = 2f)
        val hidden = layer().copy(id = 3, visible = false)
        val late = layer().copy(id = 4, inFrame = 8)
        val s = Composition(layers = listOf(top, hidden, late, bottom)).buildScene(frame = 3)
        assertEquals(2f, s[5], 0f)
        assertEquals(2f, s[SceneFormat.HEADER + 1], 0f)                          // bottom lebih dulu
        assertEquals(1f, s[SceneFormat.HEADER + SceneFormat.LAYER_STRIDE + 1], 0f)
    }

    @Test
    fun timecodeFormatsMinutesSecondsFrames() {
        assertEquals("00:00:00", formatTimecode(0, 30))
        assertEquals("00:02:15", formatTimecode(75, 30))
        assertEquals("01:01:05", formatTimecode(30 * 61 + 5, 30))
    }
}
