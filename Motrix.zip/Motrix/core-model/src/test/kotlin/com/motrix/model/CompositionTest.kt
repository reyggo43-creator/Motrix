package com.motrix.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CompositionTest {
    private val empty = Composition(width = 1000, height = 500, fps = 30, durationFrames = 90)

    private fun Composition.withOut(id: Long, out: Int) =
        copy(layers = layers.map { if (it.id == id) it.copy(outFrame = out) else it })

    @Test
    fun addLayerPutsNewLayerOnTopCenteredAndSpanningWholeDuration() {
        val c = empty.addLayer(ShapeType.RECTANGLE, 0xFF0000)
        val l = c.layers.first()
        assertEquals(1, c.layers.size)
        assertEquals(500f, l.x, 0f)
        assertEquals(250f, l.y, 0f)
        assertEquals(0, l.inFrame)
        assertEquals(90, l.outFrame)
        assertEquals(2L, c.nextId)
    }

    @Test
    fun addedLayersGetUniqueIdsAndNewestIsOnTop() {
        val c = empty.addLayer(ShapeType.RECTANGLE, 1).addLayer(ShapeType.ELLIPSE, 2)
        assertEquals(listOf(2L, 1L), c.layers.map { it.id })
        assertEquals(ShapeType.ELLIPSE, c.layers.first().shape)
    }

    @Test
    fun removeLayerDeletesOnlyThatLayer() {
        val c = empty.addLayer(ShapeType.RECTANGLE, 1).addLayer(ShapeType.ELLIPSE, 2)
        val r = c.removeLayer(1L)
        assertEquals(listOf(2L), r.layers.map { it.id })
        assertNull(r.layer(1L))
    }

    @Test
    fun moveLayerOrderSwapsAndClampsAtEnds() {
        val c = empty.addLayer(ShapeType.RECTANGLE, 1).addLayer(ShapeType.ELLIPSE, 2).addLayer(ShapeType.RECTANGLE, 3)
        assertEquals(listOf(3L, 2L, 1L), c.layers.map { it.id })
        assertEquals(listOf(2L, 3L, 1L), c.moveLayerOrder(3L, 1).layers.map { it.id })
        assertEquals(c, c.moveLayerOrder(3L, -1)) // sudah paling atas
        assertEquals(listOf(3L, 1L, 2L), c.moveLayerOrder(2L, 5).layers.map { it.id })
        assertEquals(c, c.moveLayerOrder(99L, 1)) // id tidak ada
    }

    @Test
    fun toggleVisibleFlipsFlag() {
        val c = empty.addLayer(ShapeType.RECTANGLE, 1)
        assertTrue(c.layer(1L)!!.visible)
        assertEquals(false, c.toggleVisible(1L).layer(1L)!!.visible)
    }

    @Test
    fun shiftTimeMovesWholeBarAndKeepsLength() {
        val c = empty.addLayer(ShapeType.RECTANGLE, 1).withOut(1L, 30) // 0..30
        val s = c.shiftTime(1L, 10)
        assertEquals(10, s.layer(1L)!!.inFrame)
        assertEquals(40, s.layer(1L)!!.outFrame)
    }

    @Test
    fun shiftTimeClampsInsideCompositionDuration() {
        val c = empty.addLayer(ShapeType.RECTANGLE, 1).withOut(1L, 30)
        assertEquals(0, c.shiftTime(1L, -50).layer(1L)!!.inFrame)
        val late = c.shiftTime(1L, 500).layer(1L)!!
        assertEquals(60, late.inFrame)
        assertEquals(90, late.outFrame)
    }

    @Test
    fun translateMovesLayerCenter() {
        val c = empty.addLayer(ShapeType.RECTANGLE, 1).translate(1L, 15f, -5f)
        assertEquals(515f, c.layer(1L)!!.x, 0f)
        assertEquals(245f, c.layer(1L)!!.y, 0f)
    }

    @Test
    fun layerIsActiveOnlyInsideRangeAndWhenVisible() {
        val l = empty.addLayer(ShapeType.RECTANGLE, 1).withOut(1L, 30).layer(1L)!!
        assertTrue(l.isActiveAt(0))
        assertTrue(l.isActiveAt(29))
        assertEquals(false, l.isActiveAt(30)) // outFrame eksklusif
        assertEquals(false, l.copy(visible = false).isActiveAt(5))
    }
}
