package com.motrix.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.motrix.app.editor.EditorScreen
import com.motrix.app.ui.theme.MotrixColors
import com.motrix.app.ui.theme.MotrixTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Antarmuka selalu gelap: paksa ikon system bar terang agar terbaca di atas workspace.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            MotrixTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MotrixColors.Panel) {
                    EditorScreen()
                }
            }
        }
    }
}
