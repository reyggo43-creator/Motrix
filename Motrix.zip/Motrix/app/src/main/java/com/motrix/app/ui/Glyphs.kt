package com.motrix.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

enum class GlyphKind {
    PLAY, PAUSE, TO_START, STEP_BACK, STEP_FWD,
    RECT, ELLIPSE, DELETE, UP, DOWN, UNDO, REDO, EYE, EYE_OFF,
}

private fun poly(vararg xy: Float, closed: Boolean): Path = Path().apply {
    moveTo(xy[0], xy[1])
    var i = 2
    while (i < xy.size) {
        lineTo(xy[i], xy[i + 1])
        i += 2
    }
    if (closed) close()
}

/** Ikon vektor digambar langsung di Canvas: tanpa dependensi material-icons. */
@Composable
fun Glyph(kind: GlyphKind, tint: Color, modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            GlyphKind.PLAY ->
                drawPath(poly(.3f * w, .2f * h, .3f * w, .8f * h, .82f * w, .5f * h, closed = true), tint)
            GlyphKind.PAUSE -> {
                drawRect(tint, Offset(.24f * w, .2f * h), Size(.19f * w, .6f * h))
                drawRect(tint, Offset(.57f * w, .2f * h), Size(.19f * w, .6f * h))
            }
            GlyphKind.TO_START -> {
                drawRect(tint, Offset(.2f * w, .2f * h), Size(.1f * w, .6f * h))
                drawPath(poly(.8f * w, .2f * h, .8f * w, .8f * h, .38f * w, .5f * h, closed = true), tint)
            }
            GlyphKind.STEP_BACK ->
                drawPath(poly(.62f * w, .2f * h, .36f * w, .5f * h, .62f * w, .8f * h, closed = false), tint, style = stroke)
            GlyphKind.STEP_FWD ->
                drawPath(poly(.38f * w, .2f * h, .64f * w, .5f * h, .38f * w, .8f * h, closed = false), tint, style = stroke)
            GlyphKind.RECT ->
                drawRect(tint, Offset(.18f * w, .26f * h), Size(.64f * w, .48f * h), style = stroke)
            GlyphKind.ELLIPSE ->
                drawOval(tint, Offset(.16f * w, .26f * h), Size(.68f * w, .48f * h), style = stroke)
            GlyphKind.DELETE -> {
                drawLine(tint, Offset(.3f * w, .3f * h), Offset(.7f * w, .7f * h), stroke.width, StrokeCap.Round)
                drawLine(tint, Offset(.7f * w, .3f * h), Offset(.3f * w, .7f * h), stroke.width, StrokeCap.Round)
            }
            GlyphKind.UP ->
                drawPath(poly(.25f * w, .62f * h, .5f * w, .36f * h, .75f * w, .62f * h, closed = false), tint, style = stroke)
            GlyphKind.DOWN ->
                drawPath(poly(.25f * w, .38f * h, .5f * w, .64f * h, .75f * w, .38f * h, closed = false), tint, style = stroke)
            GlyphKind.UNDO -> {
                drawArc(tint, 180f, 235f, false, Offset(.26f * w, .32f * h), Size(.5f * w, .5f * h), style = stroke)
                drawPath(poly(.12f * w, .57f * h, .40f * w, .57f * h, .26f * w, .77f * h, closed = true), tint)
            }
            GlyphKind.REDO -> {
                drawArc(tint, 0f, -235f, false, Offset(.24f * w, .32f * h), Size(.5f * w, .5f * h), style = stroke)
                drawPath(poly(.60f * w, .57f * h, .88f * w, .57f * h, .74f * w, .77f * h, closed = true), tint)
            }
            GlyphKind.EYE, GlyphKind.EYE_OFF -> {
                val eye = if (kind == GlyphKind.EYE) tint else tint.copy(alpha = tint.alpha * 0.5f)
                drawOval(eye, Offset(.1f * w, .3f * h), Size(.8f * w, .4f * h), style = stroke)
                drawCircle(eye, .1f * w, Offset(.5f * w, .5f * h))
                if (kind == GlyphKind.EYE_OFF) {
                    drawLine(tint, Offset(.2f * w, .8f * h), Offset(.8f * w, .2f * h), stroke.width, StrokeCap.Round)
                }
            }
        }
    }
}
