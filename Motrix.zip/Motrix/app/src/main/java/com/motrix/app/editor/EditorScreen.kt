package com.motrix.app.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.motrix.app.ui.Glyph
import com.motrix.app.ui.GlyphKind
import com.motrix.app.ui.theme.MotrixColors
import com.motrix.engine.MotrixGLView
import com.motrix.model.Composition
import com.motrix.model.Playhead
import com.motrix.model.ShapeType
import com.motrix.model.buildScene
import com.motrix.model.formatTimecode
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val playhead = vm.playhead.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var gpuInfo by remember { mutableStateOf("") }
    var fps by remember { mutableIntStateOf(0) }
    val glView = remember { MotrixGLView(context, onInfo = { gpuInfo = it }, onFps = { fps = it }) }

    // Siklus hidup GL.
    DisposableEffect(lifecycleOwner, glView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> glView.onResume()
                Lifecycle.Event.ON_PAUSE -> glView.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Kirim scene ke engine hanya saat composition atau frame berubah.
    LaunchedEffect(glView, vm) {
        combine(
            vm.state.map { it.composition }.distinctUntilChanged(),
            vm.playhead,
        ) { c, p -> c to p.frame(c.durationFrames) }
            .distinctUntilChanged()
            .collect { (c, frame) -> glView.setScene(c.buildScene(frame)) }
    }

    // Penggerak pemutaran: satu tick per frame layar selama playing.
    val playing by remember { derivedStateOf { playhead.value.playing } }
    LaunchedEffect(playing) {
        if (playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                vm.tick((now - last) / 1_000_000_000.0)
                last = now
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MotrixColors.Panel)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        TopBar(state.composition, gpuInfo, fps, playing)
        PreviewPane(vm, state, playhead, glView, Modifier.weight(1f).fillMaxWidth())
        TransportBar(vm, state.composition, playhead)
        ToolBar(vm, state)
        TimelinePanel(vm, state, playhead, Modifier.fillMaxWidth().height(260.dp))
    }
}

@Composable
private fun TopBar(comp: Composition, gpuInfo: String, fps: Int, playing: Boolean) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MOTRIX", color = MotrixColors.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.width(12.dp))
            Text("${comp.width}×${comp.height}  ${comp.fps} fps", color = MotrixColors.TextDim, fontSize = 11.sp)
            Spacer(Modifier.weight(1f))
            Text(if (playing) "$fps FPS render" else "Jeda", color = MotrixColors.TextDim, fontSize = 11.sp)
        }
        Text(
            gpuInfo,
            color = MotrixColors.TextDim.copy(alpha = 0.7f),
            fontSize = 9.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun TransportBar(vm: EditorViewModel, comp: Composition, playhead: State<Playhead>) {
    val p = playhead.value
    val frame = p.frame(comp.durationFrames)
    Row(
        Modifier.fillMaxWidth().background(MotrixColors.PanelAlt).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RoundButton(GlyphKind.TO_START, "Ke awal", MotrixColors.Text) { vm.toStart() }
        RoundButton(GlyphKind.STEP_BACK, "Mundur satu frame", MotrixColors.Text) { vm.stepFrames(-1) }
        RoundButton(
            kind = if (p.playing) GlyphKind.PAUSE else GlyphKind.PLAY,
            label = if (p.playing) "Jeda" else "Putar",
            tint = Color.White,
            background = MotrixColors.Accent,
        ) { vm.togglePlay() }
        RoundButton(GlyphKind.STEP_FWD, "Maju satu frame", MotrixColors.Text) { vm.stepFrames(1) }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                formatTimecode(frame, comp.fps),
                color = MotrixColors.Text,
                fontFamily = FontFamily.Monospace,
                fontSize = 16.sp,
            )
            Text("frame $frame / ${comp.durationFrames}", color = MotrixColors.TextDim, fontSize = 10.sp)
        }
        Spacer(Modifier.width(4.dp))
    }
}

@Composable
private fun RoundButton(
    kind: GlyphKind,
    label: String,
    tint: Color,
    background: Color = Color.Transparent,
    onClick: () -> Unit,
) {
    Box(
        Modifier
            .padding(2.dp)
            .size(44.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Glyph(kind, tint, Modifier.size(22.dp))
    }
}

@Composable
private fun ToolBar(vm: EditorViewModel, state: EditorState) {
    val hasSelection = state.selectedId != null
    Row(
        Modifier
            .fillMaxWidth()
            .background(MotrixColors.Panel)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start,
    ) {
        ToolButton(GlyphKind.RECT, "Persegi", true) { vm.addLayer(ShapeType.RECTANGLE) }
        ToolButton(GlyphKind.ELLIPSE, "Elips", true) { vm.addLayer(ShapeType.ELLIPSE) }
        ToolDivider()
        ToolButton(GlyphKind.UP, "Naik", hasSelection) { vm.moveSelected(-1) }
        ToolButton(GlyphKind.DOWN, "Turun", hasSelection) { vm.moveSelected(1) }
        ToolButton(GlyphKind.DELETE, "Hapus", hasSelection) { vm.deleteSelected() }
        ToolDivider()
        ToolButton(GlyphKind.UNDO, "Urungkan", state.undo.isNotEmpty()) { vm.undo() }
        ToolButton(GlyphKind.REDO, "Ulangi", state.redo.isNotEmpty()) { vm.redo() }
    }
}

@Composable
private fun ToolButton(kind: GlyphKind, label: String, enabled: Boolean, onClick: () -> Unit) {
    val tint = if (enabled) MotrixColors.Text else MotrixColors.TextDim.copy(alpha = 0.45f)
    Column(
        Modifier
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Glyph(kind, tint, Modifier.size(22.dp))
        Text(label, color = tint, fontSize = 10.sp)
    }
}

@Composable
private fun ToolDivider() {
    Box(Modifier.padding(horizontal = 4.dp).width(1.dp).height(30.dp).background(MotrixColors.Border))
}
