package com.motrix.app.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.motrix.app.ui.Glyph
import com.motrix.app.ui.GlyphKind
import com.motrix.app.ui.theme.MotrixColors
import com.motrix.app.ui.theme.toColor
import com.motrix.model.Composition
import com.motrix.model.Layer
import com.motrix.model.Playhead
import com.motrix.model.ShapeType
import kotlin.math.roundToInt

private val RowHeight = 36.dp
private val HeaderWidth = 144.dp
private val RulerHeight = 28.dp

/**
 * Panel layer (kiri) + timeline (kanan) dalam satu panel, baris sejajar dan scroll vertikal bersama.
 * Skala waktu: seluruh durasi composition dipaskan ke lebar panel (zoom/pinch menyusul bersama keyframe).
 */
@Composable
fun TimelinePanel(
    vm: EditorViewModel,
    state: EditorState,
    playhead: State<Playhead>,
    modifier: Modifier = Modifier,
) {
    val comp = state.composition
    val vScroll = rememberScrollState()
    var trackWidth by remember { mutableIntStateOf(0) }
    val ppf = if (trackWidth > 0) trackWidth.toFloat() / comp.durationFrames else 1f

    Row(modifier.background(MotrixColors.Panel)) {
        // ---- Panel layer ----
        Column(Modifier.width(HeaderWidth).fillMaxHeight()) {
            Box(
                Modifier.fillMaxWidth().height(RulerHeight).background(MotrixColors.PanelAlt).padding(start = 10.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text("Layer", color = MotrixColors.TextDim, fontSize = 11.sp)
            }
            Column(Modifier.weight(1f).verticalScroll(vScroll)) {
                if (comp.layers.isEmpty()) {
                    Text(
                        "Belum ada layer",
                        color = MotrixColors.TextDim,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(10.dp),
                    )
                }
                comp.layers.forEach { l ->
                    key(l.id) {
                        LayerHeader(
                            layer = l,
                            selected = l.id == state.selectedId,
                            onSelect = { vm.select(l.id) },
                            onToggle = { vm.toggleVisible(l.id) },
                        )
                    }
                }
            }
        }

        // ---- Timeline ----
        Box(Modifier.weight(1f).fillMaxHeight().onSizeChanged { trackWidth = it.width }) {
            Column(Modifier.fillMaxSize()) {
                Ruler(comp, ppf) { frame -> vm.seek(frame.toDouble()) }
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(vScroll)) {
                    comp.layers.forEach { l ->
                        key(l.id) { TrackRow(l, l.id == state.selectedId, ppf, vm) }
                    }
                }
            }
            PlayheadLine(playhead, ppf)
        }
    }
}

@Composable
private fun LayerHeader(layer: Layer, selected: Boolean, onSelect: () -> Unit, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(RowHeight)
            .background(if (selected) MotrixColors.Selected else Color.Transparent)
            .drawBehind {
                drawLine(MotrixColors.Border, Offset(0f, size.height), Offset(size.width, size.height), 1f)
            }
            .clickable(onClick = onSelect),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clickable(onClick = onToggle)
                .semantics {
                    contentDescription = if (layer.visible) "Sembunyikan ${layer.name}" else "Tampilkan ${layer.name}"
                },
            contentAlignment = Alignment.Center,
        ) {
            Glyph(
                if (layer.visible) GlyphKind.EYE else GlyphKind.EYE_OFF,
                if (layer.visible) MotrixColors.Text else MotrixColors.TextDim,
                Modifier.size(18.dp),
            )
        }
        Glyph(
            if (layer.shape == ShapeType.RECTANGLE) GlyphKind.RECT else GlyphKind.ELLIPSE,
            layer.color.toColor(),
            Modifier.size(14.dp),
        )
        Spacer(Modifier.width(6.dp))
        Text(
            layer.name,
            color = if (layer.visible) MotrixColors.Text else MotrixColors.TextDim,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(end = 6.dp),
        )
    }
}

@Composable
private fun Ruler(comp: Composition, ppf: Float, onSeek: (Float) -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(RulerHeight)
            .background(MotrixColors.PanelAlt)
            .pointerInput(ppf) { detectTapGestures { onSeek(it.x / ppf) } }
            .pointerInput(ppf) {
                detectDragGestures(
                    onDragStart = { onSeek(it.x / ppf) },
                    onDrag = { change, _ ->
                        change.consume()
                        onSeek(change.position.x / ppf)
                    },
                )
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            for (f in 0..comp.durationFrames) {
                val major = f % comp.fps == 0
                if (!major && f % 5 != 0) continue
                val x = f * ppf
                drawLine(
                    color = if (major) MotrixColors.TextDim else MotrixColors.Border,
                    start = Offset(x, size.height * if (major) 0.5f else 0.75f),
                    end = Offset(x, size.height),
                    strokeWidth = 1f,
                )
            }
        }
        for (s in 0..(comp.durationFrames - 1) / comp.fps) {
            Text(
                "${s}s",
                color = MotrixColors.TextDim,
                fontSize = 9.sp,
                modifier = Modifier
                    .offset { IntOffset((s * comp.fps * ppf).roundToInt() + 3, 0) }
                    .padding(top = 2.dp),
            )
        }
    }
}

@Composable
private fun TrackRow(layer: Layer, selected: Boolean, ppf: Float, vm: EditorViewModel) {
    val density = LocalDensity.current
    val remainder = remember { FloatArray(1) }
    Box(
        Modifier
            .fillMaxWidth()
            .height(RowHeight)
            .background(if (selected) MotrixColors.Selected else Color.Transparent)
            .drawBehind {
                drawLine(MotrixColors.Border, Offset(0f, size.height), Offset(size.width, size.height), 1f)
            }
            .pointerInput(layer.id) { detectTapGestures { vm.select(layer.id) } },
    ) {
        val shape = RoundedCornerShape(4.dp)
        Box(
            Modifier
                .offset { IntOffset((layer.inFrame * ppf).roundToInt(), 0) }
                .padding(vertical = 6.dp)
                .width(with(density) { (layer.length * ppf).toDp() })
                .fillMaxHeight()
                .clip(shape)
                .background(layer.color.toColor().copy(alpha = if (layer.visible) 0.85f else 0.3f))
                .then(if (selected) Modifier.border(1.5.dp, Color.White, shape) else Modifier)
                .pointerInput(layer.id) { detectTapGestures { vm.select(layer.id) } }
                .pointerInput(layer.id, ppf) {
                    detectDragGestures(
                        onDragStart = {
                            remainder[0] = 0f
                            vm.select(layer.id)
                            vm.beginGesture()
                        },
                        onDrag = { change, drag ->
                            change.consume()
                            remainder[0] += drag.x
                            val df = (remainder[0] / ppf).roundToInt()
                            if (df != 0) {
                                vm.shiftLayerTime(layer.id, df)
                                remainder[0] -= df * ppf
                            }
                        },
                    )
                },
        )
    }
}

@Composable
private fun PlayheadLine(playhead: State<Playhead>, ppf: Float) {
    Canvas(Modifier.fillMaxSize()) {
        // Dibaca di fase draw: update playhead tidak memicu recomposition panel.
        val x = (playhead.value.position * ppf).toFloat()
        val stroke = 2.dp.toPx()
        drawLine(MotrixColors.Playhead, Offset(x, 0f), Offset(x, size.height), stroke)
        val s = 6.dp.toPx()
        drawPath(
            Path().apply {
                moveTo(x - s, 0f)
                lineTo(x + s, 0f)
                lineTo(x, s * 1.4f)
                close()
            },
            MotrixColors.Playhead,
        )
    }
}
