package com.motrix.app.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.motrix.app.ui.theme.MotrixColors
import com.motrix.engine.MotrixGLView
import com.motrix.model.Composition
import com.motrix.model.Playhead
import com.motrix.model.fitRect

/** Titik layar -> koordinat composition, memakai fitRect yang sama dengan renderer GL. */
private fun toComp(p: Offset, size: IntSize, c: Composition): Offset? {
    if (size.width <= 0 || size.height <= 0) return null
    val fit = fitRect(size.width.toFloat(), size.height.toFloat(), c.width, c.height)
    if (fit.width <= 0f) return null
    return Offset((p.x - fit.left) / fit.width * c.width, (p.y - fit.top) / fit.height * c.height)
}

@Composable
fun PreviewPane(
    vm: EditorViewModel,
    state: EditorState,
    playhead: State<Playhead>,
    glView: MotrixGLView,
    modifier: Modifier = Modifier,
) {
    val current by rememberUpdatedState(state)

    Box(modifier.background(MotrixColors.Pasteboard)) {
        AndroidView(factory = { glView }, modifier = Modifier.fillMaxSize())

        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        toComp(offset, size, current.composition)?.let { vm.selectAt(it.x, it.y) }
                    }
                }
                .pointerInput(Unit) {
                    var dragging = false
                    detectDragGestures(
                        onDragStart = { offset ->
                            val c = current.composition
                            val layer = current.selectedId?.let { c.layer(it) }
                            val p = toComp(offset, size, c)
                            val frame = playhead.value.frame(c.durationFrames)
                            dragging = layer != null && p != null &&
                                layer.isActiveAt(frame) && layer.contains(p.x, p.y)
                            if (dragging) vm.beginGesture()
                        },
                        onDrag = { change, drag ->
                            if (dragging) {
                                change.consume()
                                val c = current.composition
                                val fit = fitRect(size.width.toFloat(), size.height.toFloat(), c.width, c.height)
                                val k = c.width / fit.width
                                current.selectedId?.let { vm.translateLayer(it, drag.x * k, drag.y * k) }
                            }
                        },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                    )
                },
        ) {
            val c = state.composition
            val layer = state.selectedId?.let { c.layer(it) } ?: return@Canvas
            if (!layer.isActiveAt(playhead.value.frame(c.durationFrames))) return@Canvas
            val fit = fitRect(this.size.width, this.size.height, c.width, c.height)
            val k = fit.width / c.width
            val cs = layer.corners()
            val outline = Path().apply {
                moveTo(fit.left + cs[0] * k, fit.top + cs[1] * k)
                for (i in 1..3) lineTo(fit.left + cs[i * 2] * k, fit.top + cs[i * 2 + 1] * k)
                close()
            }
            drawPath(outline, MotrixColors.Accent, style = Stroke(width = 1.5.dp.toPx()))
        }

        if (state.composition.layers.isEmpty()) {
            Text(
                "Kanvas kosong. Tambah layer dari toolbar.",
                color = MotrixColors.TextDim,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.Center),
            )
        }
    }
}
