package com.motrix.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Palet workspace: ruang kerja gelap netral, satu aksen biru, satu warna playhead. */
object MotrixColors {
    val Pasteboard = Color(0xFF090A0E)
    val Panel = Color(0xFF14161D)
    val PanelAlt = Color(0xFF191C25)
    val Border = Color(0xFF262A36)
    val Selected = Color(0xFF222B42)
    val Accent = Color(0xFF4F8CFF)
    val Playhead = Color(0xFFFF4D6A)
    val Text = Color(0xFFE6E8EE)
    val TextDim = Color(0xFF8A90A0)
}

/** Warna layer (RGB 0xRRGGBB) menjadi Color opak. */
fun Int.toColor(): Color = Color(this or (0xFF shl 24))

private val MotrixDark = darkColorScheme(
    primary = MotrixColors.Accent,
    background = MotrixColors.Panel,
    surface = MotrixColors.Panel,
    onBackground = MotrixColors.Text,
    onSurface = MotrixColors.Text,
)

@Composable
fun MotrixTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MotrixDark, content = content)
}
