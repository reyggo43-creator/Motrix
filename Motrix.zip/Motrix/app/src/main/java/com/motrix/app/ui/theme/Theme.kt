package com.motrix.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MotrixDark = darkColorScheme(
    primary = Color(0xFF4F8CFF),
    background = Color(0xFF0F1117),
    surface = Color(0xFF171A22),
    onBackground = Color(0xFFE6E8EE),
    onSurface = Color(0xFFE6E8EE),
)

@Composable
fun MotrixTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MotrixDark, content = content)
}
