package com.motrix.app.editor

import androidx.lifecycle.ViewModel
import com.motrix.model.Composition
import com.motrix.model.Playhead
import com.motrix.model.ShapeType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.floor

data class EditorState(
    val composition: Composition = Composition.starter(),
    val selectedId: Long? = null,
    val undo: List<Composition> = emptyList(),
    val redo: List<Composition> = emptyList(),
)

private const val MAX_HISTORY = 100
private val PALETTE = intArrayOf(0x4F8CFF, 0xFF4D6A, 0x4DE0A0, 0xFFC857, 0xB07CFF, 0x35D0E8)

private fun EditorState.pushed(n: Composition, selected: Long? = selectedId) = copy(
    composition = n,
    selectedId = selected,
    undo = (undo + composition).takeLast(MAX_HISTORY),
    redo = emptyList(),
)

private fun Long?.keepIfIn(c: Composition): Long? = if (this != null && c.layer(this) != null) this else null

class EditorViewModel : ViewModel() {

    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state.asStateFlow()

    // Playhead dipisah dari state dokumen: berubah ~60x/detik saat play, dokumen tidak.
    private val _playhead = MutableStateFlow(Playhead())
    val playhead: StateFlow<Playhead> = _playhead.asStateFlow()

    // ---------- Dokumen ----------

    fun select(id: Long?) = _state.update { it.copy(selectedId = id) }

    /** Pilih layer teratas yang aktif di frame saat ini dan mengenai titik (koordinat composition). */
    fun selectAt(x: Float, y: Float) {
        val c = _state.value.composition
        val frame = _playhead.value.frame(c.durationFrames)
        select(c.layers.firstOrNull { it.isActiveAt(frame) && it.contains(x, y) }?.id)
    }

    fun addLayer(shape: ShapeType) = _state.update { s ->
        val n = s.composition.addLayer(shape, PALETTE[(s.composition.nextId % PALETTE.size).toInt()])
        s.pushed(n, selected = n.layers.first().id)
    }

    fun deleteSelected() = _state.update { s ->
        val id = s.selectedId ?: return@update s
        s.pushed(s.composition.removeLayer(id), selected = null)
    }

    /** delta negatif = naik (mendekati layer paling atas). */
    fun moveSelected(delta: Int) = _state.update { s ->
        val id = s.selectedId ?: return@update s
        val n = s.composition.moveLayerOrder(id, delta)
        if (n == s.composition) s else s.pushed(n)
    }

    fun toggleVisible(id: Long) = _state.update { s -> s.pushed(s.composition.toggleVisible(id)) }

    /** Panggil sekali di awal gerakan drag; perubahan selama drag tidak mencatat riwayat lagi. */
    fun beginGesture() = _state.update { s ->
        s.copy(undo = (s.undo + s.composition).takeLast(MAX_HISTORY), redo = emptyList())
    }

    fun shiftLayerTime(id: Long, deltaFrames: Int) =
        _state.update { it.copy(composition = it.composition.shiftTime(id, deltaFrames)) }

    fun translateLayer(id: Long, dx: Float, dy: Float) =
        _state.update { it.copy(composition = it.composition.translate(id, dx, dy)) }

    fun undo() = _state.update { s ->
        val prev = s.undo.lastOrNull() ?: return@update s
        s.copy(
            composition = prev,
            undo = s.undo.dropLast(1),
            redo = s.redo + s.composition,
            selectedId = s.selectedId.keepIfIn(prev),
        )
    }

    fun redo() = _state.update { s ->
        val next = s.redo.lastOrNull() ?: return@update s
        s.copy(
            composition = next,
            undo = s.undo + s.composition,
            redo = s.redo.dropLast(1),
            selectedId = s.selectedId.keepIfIn(next),
        )
    }

    // ---------- Pemutaran ----------

    fun togglePlay() = _playhead.update { it.copy(playing = !it.playing) }

    /** Dipanggil tiap frame layar saat playing. */
    fun tick(dtSeconds: Double) {
        val c = _state.value.composition
        _playhead.update { it.advance(dtSeconds, c.fps, c.durationFrames) }
    }

    /** Lompat ke frame (dibulatkan ke bawah agar playhead selalu tepat di batas frame). */
    fun seek(frame: Double) {
        val c = _state.value.composition
        _playhead.update { it.seek(floor(frame), c.durationFrames) }
    }

    fun stepFrames(delta: Int) {
        val c = _state.value.composition
        _playhead.update { p -> p.copy(playing = false).seek(floor(p.position) + delta, c.durationFrames) }
    }

    fun toStart() = seek(0.0)
}
