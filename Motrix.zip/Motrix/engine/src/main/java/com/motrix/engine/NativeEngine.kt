package com.motrix.engine

/** Jembatan JNI ke engine C++. Semua fungsi harus dipanggil dari GL thread. */
object NativeEngine {

    init {
        System.loadLibrary("motrix_engine")
    }

    @JvmStatic external fun nativeInit(): Boolean
    @JvmStatic external fun nativeResize(width: Int, height: Int)
    @JvmStatic external fun nativeRender(timeSeconds: Float)
    @JvmStatic external fun nativeGlInfo(): String
}
