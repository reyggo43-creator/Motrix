package com.motrix.engine

/** Jembatan JNI ke engine C++. Semua fungsi harus dipanggil dari GL thread. */
object NativeEngine {

    init {
        System.loadLibrary("motrix_engine")
    }

    @JvmStatic external fun nativeInit(): Boolean
    @JvmStatic external fun nativeResize(width: Int, height: Int)

    /**
     * Gambar satu frame. (vx, vy, vw, vh) = viewport composition dalam piksel surface,
     * origin kiri-bawah. [scene] berformat SceneFormat (lihat core-model).
     */
    @JvmStatic external fun nativeRenderScene(vx: Int, vy: Int, vw: Int, vh: Int, scene: FloatArray)

    @JvmStatic external fun nativeGlInfo(): String
}
