package com.motrix.engine

import android.content.Context
import android.opengl.GLSurfaceView

/** Viewport OpenGL ES 3.0 milik engine MOTRIX. */
class MotrixGLView(
    context: Context,
    onInfo: (String) -> Unit,
    onFps: (Int) -> Unit,
) : GLSurfaceView(context) {

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        preserveEGLContextOnPause = false
        setRenderer(MotrixRenderer(onInfo, onFps))
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}
