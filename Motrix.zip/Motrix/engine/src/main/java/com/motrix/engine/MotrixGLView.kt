package com.motrix.engine

import android.content.Context
import android.opengl.GLSurfaceView

/** Viewport OpenGL ES 3.0 milik engine MOTRIX. Menggambar hanya saat scene berubah. */
class MotrixGLView(
    context: Context,
    onInfo: (String) -> Unit,
    onFps: (Int) -> Unit,
) : GLSurfaceView(context) {

    private val renderer = MotrixRenderer(onInfo, onFps)

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    /** Aman dipanggil dari UI thread. */
    fun setScene(scene: FloatArray) {
        renderer.scene = scene
        requestRender()
    }
}
