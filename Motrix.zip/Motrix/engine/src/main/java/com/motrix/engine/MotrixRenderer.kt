package com.motrix.engine

import android.opengl.GLSurfaceView
import android.os.SystemClock
import com.motrix.model.SceneFormat
import com.motrix.model.fitRect
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.roundToInt

/** Menghubungkan siklus hidup GLSurfaceView ke engine native. Berjalan di GL thread. */
class MotrixRenderer(
    private val onInfo: (String) -> Unit,
    private val onFps: (Int) -> Unit,
) : GLSurfaceView.Renderer {

    /** Scene terbaru dari UI thread. Larik tidak pernah dimutasi setelah diset, hanya diganti. */
    @Volatile
    var scene: FloatArray = FloatArray(0)

    private var surfaceW = 1
    private var surfaceH = 1
    private var windowStartNanos = 0L
    private var lastFrameNanos = 0L
    private var frames = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val ok = NativeEngine.nativeInit()
        onInfo(if (ok) NativeEngine.nativeGlInfo() else "Inisialisasi engine GAGAL (lihat logcat: MotrixEngine)")
        windowStartNanos = 0L
        lastFrameNanos = 0L
        frames = 0
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceW = width
        surfaceH = height
        NativeEngine.nativeResize(width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val s = scene
        val compW = if (s.size >= SceneFormat.HEADER) s[0].toInt() else 0
        val compH = if (s.size >= SceneFormat.HEADER) s[1].toInt() else 0
        if (compW > 0 && compH > 0) {
            val fit = fitRect(surfaceW.toFloat(), surfaceH.toFloat(), compW, compH)
            NativeEngine.nativeRenderScene(
                fit.left.roundToInt(),
                surfaceH - (fit.top + fit.height).roundToInt(),
                fit.width.roundToInt(),
                fit.height.roundToInt(),
                s,
            )
        } else {
            NativeEngine.nativeRenderScene(0, 0, 0, 0, s)
        }
        countFrame()
    }

    // Render hanya saat ada perubahan (RENDERMODE_WHEN_DIRTY): jendela FPS direset setelah jeda.
    private fun countFrame() {
        val now = SystemClock.elapsedRealtimeNanos()
        if (lastFrameNanos == 0L || now - lastFrameNanos > 500_000_000L) {
            windowStartNanos = now
            frames = 0
        }
        lastFrameNanos = now
        frames++
        val elapsed = now - windowStartNanos
        if (elapsed >= 1_000_000_000L) {
            onFps((frames * 1_000_000_000L / elapsed).toInt())
            frames = 0
            windowStartNanos = now
        }
    }
}
