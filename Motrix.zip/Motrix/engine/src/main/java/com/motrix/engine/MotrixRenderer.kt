package com.motrix.engine

import android.opengl.GLSurfaceView
import android.os.SystemClock
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Menghubungkan siklus hidup GLSurfaceView ke engine native. Berjalan di GL thread. */
class MotrixRenderer(
    private val onInfo: (String) -> Unit,
    private val onFps: (Int) -> Unit,
) : GLSurfaceView.Renderer {

    private var startNanos = 0L
    private var windowStartNanos = 0L
    private var frames = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val ok = NativeEngine.nativeInit()
        onInfo(if (ok) NativeEngine.nativeGlInfo() else "Inisialisasi engine GAGAL (lihat logcat: MotrixEngine)")
        startNanos = SystemClock.elapsedRealtimeNanos()
        windowStartNanos = startNanos
        frames = 0
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        NativeEngine.nativeResize(width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = SystemClock.elapsedRealtimeNanos()
        NativeEngine.nativeRender((now - startNanos) / 1_000_000_000f)

        frames++
        val elapsed = now - windowStartNanos
        if (elapsed >= 1_000_000_000L) {
            onFps((frames * 1_000_000_000L / elapsed).toInt())
            frames = 0
            windowStartNanos = now
        }
    }
}
