#include "renderer.h"

#include "log.h"

namespace motrix {

namespace {

// Quad satuan [-0.5, 0.5]; ukuran, rotasi, dan posisi diterapkan di vertex shader.
const char* kVertexSrc = R"(#version 300 es
layout(location = 0) in vec2 aPos;
uniform vec2 uComp;
uniform vec2 uCenter;
uniform vec2 uSize;
uniform float uRot;
out vec2 vUv;
void main() {
    vec2 p = aPos * uSize;
    float c = cos(uRot);
    float s = sin(uRot);
    p = vec2(c * p.x - s * p.y, s * p.x + c * p.y) + uCenter;
    gl_Position = vec4(p.x / uComp.x * 2.0 - 1.0, 1.0 - p.y / uComp.y * 2.0, 0.0, 1.0);
    vUv = aPos;
}
)";

// uShape: 0 = persegi, 1 = elips. Tepi di-antialias dengan fwidth.
const char* kFragmentSrc = R"(#version 300 es
precision mediump float;
in vec2 vUv;
uniform vec4 uColor;
uniform int uShape;
out vec4 outColor;
void main() {
    float d = (uShape == 1) ? length(vUv) * 2.0 : max(abs(vUv.x), abs(vUv.y)) * 2.0;
    float w = max(fwidth(d), 1e-4);
    float a = 1.0 - smoothstep(1.0 - w, 1.0, d);
    outColor = vec4(uColor.rgb, uColor.a * a);
}
)";

const GLfloat kQuad[] = {
    -0.5f, -0.5f,
     0.5f, -0.5f,
    -0.5f,  0.5f,
     0.5f,  0.5f,
};

}  // namespace

Renderer::~Renderer() {
    if (vbo_ != 0) glDeleteBuffers(1, &vbo_);
    if (vao_ != 0) glDeleteVertexArrays(1, &vao_);
}

void Renderer::abandon() {
    vao_ = 0;
    vbo_ = 0;
    program_.abandon();
}

bool Renderer::init() {
    if (!program_.build(kVertexSrc, kFragmentSrc)) {
        return false;
    }
    uComp_ = program_.uniformLocation("uComp");
    uCenter_ = program_.uniformLocation("uCenter");
    uSize_ = program_.uniformLocation("uSize");
    uRot_ = program_.uniformLocation("uRot");
    uColor_ = program_.uniformLocation("uColor");
    uShape_ = program_.uniformLocation("uShape");

    glGenVertexArrays(1, &vao_);
    glGenBuffers(1, &vbo_);
    glBindVertexArray(vao_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(kQuad), kQuad, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(GLfloat), nullptr);
    glBindVertexArray(0);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR) {
        LOGE("GL error saat init: 0x%x", err);
        return false;
    }
    LOGI("Renderer siap: %s", glInfo().c_str());
    return true;
}

void Renderer::resize(int width, int height) {
    width_ = width > 0 ? width : 1;
    height_ = height > 0 ? height : 1;
}

void Renderer::render(int vx, int vy, int vw, int vh, const float* scene, int sceneLen) {
    // 1. Pasteboard (seluruh surface).
    glDisable(GL_SCISSOR_TEST);
    glViewport(0, 0, width_, height_);
    glClearColor(0.035f, 0.039f, 0.055f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    // Batas kepercayaan: data dari JVM divalidasi sebelum dibaca.
    if (scene == nullptr || sceneLen < kSceneHeader || vw <= 0 || vh <= 0) return;
    const float countF = scene[5];
    if (!(countF >= 0.0f) || countF > static_cast<float>((sceneLen - kSceneHeader) / kLayerStride)) {
        LOGE("Scene tidak valid: count=%f len=%d", countF, sceneLen);
        return;
    }
    const int count = static_cast<int>(countF);

    // 2. Kanvas composition, dipotong ke persegi viewport.
    glViewport(vx, vy, vw, vh);
    glEnable(GL_SCISSOR_TEST);
    glScissor(vx, vy, vw, vh);
    glClearColor(scene[2], scene[3], scene[4], 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    // 3. Layer, dari bawah ke atas.
    if (count > 0) {
        glEnable(GL_BLEND);
        glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ZERO, GL_ONE);
        program_.use();
        glUniform2f(uComp_, scene[0], scene[1]);
        glBindVertexArray(vao_);
        for (int i = 0; i < count; ++i) {
            const float* l = scene + kSceneHeader + i * kLayerStride;
            glUniform1i(uShape_, static_cast<int>(l[0]));
            glUniform2f(uCenter_, l[1], l[2]);
            glUniform2f(uSize_, l[3], l[4]);
            glUniform1f(uRot_, l[5]);
            glUniform4f(uColor_, l[6], l[7], l[8], l[9]);
            glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        }
        glBindVertexArray(0);
        glDisable(GL_BLEND);
    }
    glDisable(GL_SCISSOR_TEST);
}

std::string Renderer::glInfo() const {
    auto str = [](GLenum name) {
        const GLubyte* s = glGetString(name);
        return s ? std::string(reinterpret_cast<const char*>(s)) : std::string("?");
    };
    return str(GL_RENDERER) + " | " + str(GL_VERSION);
}

}  // namespace motrix
