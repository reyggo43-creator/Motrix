#include "renderer.h"

#include "log.h"

namespace motrix {

namespace {

const char* kVertexSrc = R"(#version 300 es
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec3 aColor;
uniform float uTime;
uniform float uAspect;
out vec3 vColor;
void main() {
    float c = cos(uTime);
    float s = sin(uTime);
    vec2 p = vec2(c * aPos.x - s * aPos.y, s * aPos.x + c * aPos.y);
    p.x /= uAspect;
    gl_Position = vec4(p, 0.0, 1.0);
    vColor = aColor;
}
)";

const char* kFragmentSrc = R"(#version 300 es
precision mediump float;
in vec3 vColor;
out vec4 outColor;
void main() {
    outColor = vec4(vColor, 1.0);
}
)";

// x, y, r, g, b
const GLfloat kVertices[] = {
     0.0f,  0.6f,  0.20f, 0.55f, 1.00f,
    -0.52f, -0.3f, 1.00f, 0.30f, 0.45f,
     0.52f, -0.3f, 0.30f, 1.00f, 0.55f,
};

}  // namespace

Renderer::~Renderer() {
    if (vbo_ != 0) glDeleteBuffers(1, &vbo_);
    if (vao_ != 0) glDeleteVertexArrays(1, &vao_);
}

void Renderer::abandon() {
    vao_ = 0;
    vbo_ = 0;
    program_.abandon();
}

bool Renderer::init() {
    if (!program_.build(kVertexSrc, kFragmentSrc)) {
        return false;
    }
    uTime_ = program_.uniformLocation("uTime");
    uAspect_ = program_.uniformLocation("uAspect");

    glGenVertexArrays(1, &vao_);
    glGenBuffers(1, &vbo_);
    glBindVertexArray(vao_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(kVertices), kVertices, GL_STATIC_DRAW);

    const GLsizei stride = 5 * sizeof(GLfloat);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, nullptr);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride,
                          reinterpret_cast<void*>(2 * sizeof(GLfloat)));
    glBindVertexArray(0);

    glClearColor(0.06f, 0.07f, 0.09f, 1.0f);

    GLenum err = glGetError();
    if (err != GL_NO_ERROR) {
        LOGE("GL error saat init: 0x%x", err);
        return false;
    }
    LOGI("Renderer siap: %s", glInfo().c_str());
    return true;
}

void Renderer::resize(int width, int height) {
    width_ = width > 0 ? width : 1;
    height_ = height > 0 ? height : 1;
    glViewport(0, 0, width_, height_);
}

void Renderer::render(float timeSeconds) {
    glClear(GL_COLOR_BUFFER_BIT);
    program_.use();
    glUniform1f(uTime_, timeSeconds);
    glUniform1f(uAspect_, static_cast<float>(width_) / static_cast<float>(height_));
    glBindVertexArray(vao_);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glBindVertexArray(0);
}

std::string Renderer::glInfo() const {
    auto str = [](GLenum name) {
        const GLubyte* s = glGetString(name);
        return s ? std::string(reinterpret_cast<const char*>(s)) : std::string("?");
    };
    return str(GL_RENDERER) + " | " + str(GL_VERSION);
}

}  // namespace motrix
