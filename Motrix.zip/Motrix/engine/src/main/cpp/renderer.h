#pragma once

#include <GLES3/gl3.h>

#include <string>

#include "shader_program.h"

namespace motrix {

class Renderer {
public:
    Renderer() = default;
    ~Renderer();

    Renderer(const Renderer&) = delete;
    Renderer& operator=(const Renderer&) = delete;

    bool init();
    void resize(int width, int height);
    void render(float timeSeconds);
    std::string glInfo() const;

    // EGL context sudah hilang: lepaskan semua handle tanpa memanggil GL.
    void abandon();

private:
    ShaderProgram program_;
    GLuint vao_ = 0;
    GLuint vbo_ = 0;
    GLint uTime_ = -1;
    GLint uAspect_ = -1;
    int width_ = 1;
    int height_ = 1;
};

}  // namespace motrix
