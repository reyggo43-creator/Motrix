#pragma once

#include <GLES3/gl3.h>

#include <string>

#include "shader_program.h"

namespace motrix {

// Format scene — harus sama dengan SceneFormat di core-model (Scene.kt):
//   header   : [compW, compH, bgR, bgG, bgB, layerCount]
//   per layer: [shape, cx, cy, w, h, rotasiRad, r, g, b, opacity]
constexpr int kSceneHeader = 6;
constexpr int kLayerStride = 10;

class Renderer {
public:
    Renderer() = default;
    ~Renderer();

    Renderer(const Renderer&) = delete;
    Renderer& operator=(const Renderer&) = delete;

    bool init();
    void resize(int width, int height);

    // (vx, vy, vw, vh): viewport composition dalam piksel surface, origin kiri-bawah.
    void render(int vx, int vy, int vw, int vh, const float* scene, int sceneLen);

    std::string glInfo() const;

    // EGL context sudah hilang: lepaskan semua handle tanpa memanggil GL.
    void abandon();

private:
    ShaderProgram program_;
    GLuint vao_ = 0;
    GLuint vbo_ = 0;
    GLint uComp_ = -1;
    GLint uCenter_ = -1;
    GLint uSize_ = -1;
    GLint uRot_ = -1;
    GLint uColor_ = -1;
    GLint uShape_ = -1;
    int width_ = 1;
    int height_ = 1;
};

}  // namespace motrix
