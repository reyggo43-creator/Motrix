#include "shader_program.h"

#include <vector>

#include "log.h"

namespace motrix {

ShaderProgram::~ShaderProgram() {
    if (program_ != 0) {
        glDeleteProgram(program_);
        program_ = 0;
    }
}

GLuint ShaderProgram::compile(GLenum type, const char* src) {
    GLuint shader = glCreateShader(type);
    if (shader == 0) {
        LOGE("glCreateShader gagal");
        return 0;
    }
    glShaderSource(shader, 1, &src, nullptr);
    glCompileShader(shader);

    GLint ok = GL_FALSE;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
    if (ok != GL_TRUE) {
        GLint len = 0;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> log(len > 1 ? len : 1);
        glGetShaderInfoLog(shader, static_cast<GLsizei>(log.size()), nullptr, log.data());
        LOGE("Kompilasi shader gagal: %s", log.data());
        glDeleteShader(shader);
        return 0;
    }
    return shader;
}

bool ShaderProgram::build(const char* vertexSrc, const char* fragmentSrc) {
    GLuint vs = compile(GL_VERTEX_SHADER, vertexSrc);
    GLuint fs = compile(GL_FRAGMENT_SHADER, fragmentSrc);
    if (vs == 0 || fs == 0) {
        if (vs != 0) glDeleteShader(vs);
        if (fs != 0) glDeleteShader(fs);
        return false;
    }

    GLuint prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    glDeleteShader(vs);
    glDeleteShader(fs);

    GLint ok = GL_FALSE;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (ok != GL_TRUE) {
        GLint len = 0;
        glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> log(len > 1 ? len : 1);
        glGetProgramInfoLog(prog, static_cast<GLsizei>(log.size()), nullptr, log.data());
        LOGE("Link program gagal: %s", log.data());
        glDeleteProgram(prog);
        return false;
    }

    program_ = prog;
    return true;
}

void ShaderProgram::use() const {
    glUseProgram(program_);
}

GLint ShaderProgram::uniformLocation(const char* name) const {
    return glGetUniformLocation(program_, name);
}

}  // namespace motrix
