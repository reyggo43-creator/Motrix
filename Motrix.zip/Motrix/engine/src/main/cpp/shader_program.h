#pragma once

#include <GLES3/gl3.h>

namespace motrix {

class ShaderProgram {
public:
    ShaderProgram() = default;
    ~ShaderProgram();

    ShaderProgram(const ShaderProgram&) = delete;
    ShaderProgram& operator=(const ShaderProgram&) = delete;

    bool build(const char* vertexSrc, const char* fragmentSrc);
    void use() const;
    GLint uniformLocation(const char* name) const;

    // Dipanggil saat EGL context sudah hilang: lepaskan handle tanpa memanggil GL.
    void abandon() { program_ = 0; }

private:
    static GLuint compile(GLenum type, const char* src);

    GLuint program_ = 0;
};

}  // namespace motrix
