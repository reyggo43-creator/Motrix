#pragma once

#include <android/log.h>

#define MOTRIX_TAG "MotrixEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, MOTRIX_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, MOTRIX_TAG, __VA_ARGS__)
