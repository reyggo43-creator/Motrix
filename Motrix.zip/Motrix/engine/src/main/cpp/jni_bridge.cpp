#include <jni.h>

#include <memory>
#include <string>
#include <vector>

#include "log.h"
#include "renderer.h"

namespace {
// Hanya disentuh dari GL thread milik GLSurfaceView.
std::unique_ptr<motrix::Renderer> g_renderer;
std::vector<float> g_sceneBuf;  // dipakai ulang tiap frame, tanpa alokasi
}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_motrix_engine_NativeEngine_nativeInit(JNIEnv*, jclass) {
    if (g_renderer) {
        g_renderer->abandon();  // context lama sudah hilang
        g_renderer.reset();
    }
    auto renderer = std::make_unique<motrix::Renderer>();
    if (!renderer->init()) {
        return JNI_FALSE;
    }
    g_renderer = std::move(renderer);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_motrix_engine_NativeEngine_nativeResize(JNIEnv*, jclass, jint w, jint h) {
    if (g_renderer) g_renderer->resize(w, h);
}

JNIEXPORT void JNICALL
Java_com_motrix_engine_NativeEngine_nativeRenderScene(JNIEnv* env, jclass, jint vx, jint vy, jint vw,
                                                 jint vh, jfloatArray scene) {
    if (!g_renderer) return;
    const jsize len = scene != nullptr ? env->GetArrayLength(scene) : 0;
    g_sceneBuf.resize(static_cast<size_t>(len));
    if (len > 0) env->GetFloatArrayRegion(scene, 0, len, g_sceneBuf.data());
    g_renderer->render(vx, vy, vw, vh, g_sceneBuf.data(), static_cast<int>(len));
}

JNIEXPORT jstring JNICALL
Java_com_motrix_engine_NativeEngine_nativeGlInfo(JNIEnv* env, jclass) {
    std::string info = g_renderer ? g_renderer->glInfo() : "engine belum siap";
    return env->NewStringUTF(info.c_str());
}

}  // extern "C"
