cmake_minimum_required(VERSION 3.22.1)
project(motrix_engine LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(motrix_engine SHARED
    jni_bridge.cpp
    renderer.cpp
    shader_program.cpp
)

find_library(log-lib log)

target_link_libraries(motrix_engine
    GLESv3
    EGL
    ${log-lib}
)

target_compile_options(motrix_engine PRIVATE -Wall -Wextra -O2)

# Kompatibel dengan perangkat Android 15+ berhalaman memori 16 KB
target_link_options(motrix_engine PRIVATE -Wl,-z,max-page-size=16384)
