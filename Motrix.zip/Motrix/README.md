# MOTRIX — Tahap 1: Fondasi

Aplikasi motion graphics Android (Kotlin, Jetpack Compose, C++17, OpenGL ES 3.0).
Tahap 1 berisi pipeline render native yang sungguhan: segitiga berputar dirender oleh C++/GLES,
ditampilkan di Compose, lengkap dengan info GPU dan FPS nyata.

## Prasyarat
- Android Studio Ladybug (2024.2) atau lebih baru
- JDK 17 (bawaan Android Studio sudah cukup)
- SDK Platform 35
- SDK Tools: **NDK (Side by side)** dan **CMake 3.22.1** (Settings > Languages & Frameworks > Android SDK > SDK Tools)
- Koneksi internet untuk sync Gradle pertama kali

## Build APK lewat Android Studio
1. Ekstrak ZIP, lalu **File > Open** dan pilih folder `Motrix`.
2. Tunggu Gradle sync selesai (pertama kali mengunduh Gradle 8.9 dan dependensi).
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK lewat terminal
Wrapper (`gradlew`) tidak ikut di ZIP. Setelah project terbuka di Android Studio, atau kalau Gradle 8.9+ terpasang:
```
gradle wrapper --gradle-version 8.9
./gradlew :app:assembleDebug
```
Windows: `gradlew.bat :app:assembleDebug`

## Pasang ke perangkat
```
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
Emulator harus memakai grafis **Hardware**, bukan Software.

## Checklist keberhasilan
- Segitiga berwarna berputar, FPS dan teks `GL_RENDERER | GL_VERSION` tampil di kiri atas.
- Tekan Home lalu buka lagi, dan rotasi layar: tidak crash, render lanjut.
- Logcat filter `MotrixEngine` menampilkan `Renderer siap: ...`.

## Struktur
- `app/` — UI Compose (Activity, tema, viewport)
- `engine/` — modul native: `src/main/cpp` (C++ renderer, shader, JNI) dan `src/main/java` (GLSurfaceView + jembatan JNI)

## Masalah umum
- `No version of NDK matched` / `CMake 3.22.1 not found`: pasang lewat SDK Manager > SDK Tools.
- `Unsupported Java`: set Gradle JDK ke 17 (Settings > Build Tools > Gradle).
- Layar hitam dan teks "Inisialisasi engine GAGAL": lihat logcat `MotrixEngine` untuk log shader/GL.

Rilis (minify) belum diaktifkan; aturan keep JNI akan ditambahkan di tahap rilis.
