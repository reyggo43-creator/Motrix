# MOTRIX — Tahap 2: UI Editor

Aplikasi motion graphics Android (Kotlin, Jetpack Compose, C++17, OpenGL ES 3.0).

## Yang berfungsi di tahap ini
- **Preview canvas**: composition 1920×1080 dirender engine C++/GLES (persegi dan elips, rotasi, opacity, antialias) dalam letterbox. Tap untuk memilih layer, seret layer terpilih untuk memindahkan.
- **Panel layer**: daftar layer, pilih, tampil/sembunyi (ikon mata).
- **Timeline**: ruler detik/frame, bar rentang waktu tiap layer (geser bar = geser waktu layer), playhead yang bisa di-scrub (tap/seret di ruler).
- **Toolbar**: tambah Persegi/Elips, naik/turun urutan, hapus, urungkan/ulangi (riwayat 100 langkah).
- **Transport**: putar/jeda (loop), ke awal, maju/mundur satu frame, timecode `mm:ss:ff`.
- Render hanya saat ada perubahan (hemat baterai di perangkat menengah).

Belum ada (tahap berikutnya): keyframe, panel properti, zoom timeline, trim bar, simpan/buka proyek, ekspor video.

## Prasyarat
Android Studio Ladybug+, JDK 17, SDK Platform 35, NDK dan CMake 3.22.1 (SDK Manager > SDK Tools), internet untuk sync pertama.

## Build APK
1. **Hapus folder project Tahap 1 lama** (atau ekstrak ZIP ini ke folder baru), lalu **File > Open** folder `Motrix`.
2. **File > Sync Project with Gradle Files**.
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)** — hasil: `app/build/outputs/apk/debug/app-debug.apk`.
4. Terminal: `./gradlew :core-model:test :app:assembleDebug` (buat wrapper dulu dengan `gradle wrapper --gradle-version 8.9` bila belum ada).

## Tes
`./gradlew :core-model:test` — tes unit model (composition, playhead, fit, hit-test, format scene, timecode).

## Struktur
- `core-model/` — Kotlin murni: Composition, Layer, Playhead, fitRect, format scene (tanpa dependensi Android, teruji unit)
- `engine/` — C++ (renderer, shader, JNI) + GLSurfaceView
- `app/` — UI Compose: `editor/` (EditorScreen, PreviewPane, TimelinePanel, EditorViewModel), `ui/` (tema, ikon)

## API native (JNI)
`nativeInit`, `nativeResize`, `nativeGlInfo` tidak berubah. `nativeRender(Float)` (segitiga demo) diganti
`nativeRenderScene(vx, vy, vw, vh, FloatArray)`; format larik didokumentasikan di `core-model/.../Scene.kt`
dan `engine/src/main/cpp/renderer.h`.

## Jika masih tampil segitiga
Anda masih menjalankan build Tahap 1. Pastikan membuka folder dari ZIP Tahap 2, lakukan **Build > Clean Project**,
lalu pasang ulang APK baru (uninstall dulu versi lama).
